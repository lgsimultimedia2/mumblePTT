package com.jio.jiotalkie.model;

import java.util.List;

public class PaginatedPersonalChat {

    private List<JioTalkieChats> chats;
    private boolean isLast;

    private int userIdReceiver;
    private int userIdSender;

    public PaginatedPersonalChat(List<JioTalkieChats> chats, boolean isLast, int userIdReceiver, int userIdSender) {
        this.chats = chats;
        this.isLast = isLast;
        this.userIdReceiver = userIdReceiver;
        this.userIdSender = userIdSender;
    }

    public List<JioTalkieChats> getChats() {
        return chats;
    }

    public boolean isLast() {
        return isLast;
    }

    public int getUserIdReceiver() {
        return userIdReceiver;
    }

    public int getUserIdSender() {
        return userIdSender;
    }
}
