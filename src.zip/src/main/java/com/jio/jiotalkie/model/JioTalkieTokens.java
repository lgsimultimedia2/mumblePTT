package com.jio.jiotalkie.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "jio_talkie_tokens_table")
public class JioTalkieTokens {
    @PrimaryKey(autoGenerate = true)
    private int _id;
    @NonNull
    @ColumnInfo(name = "value")
    private String value;
    @NonNull
    @ColumnInfo(name = "server")
    private int server;

    public JioTalkieTokens(@NonNull String value, int server) {
        this.value = value;
        this.server = server;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    @NonNull
    public String getValue() {
        return value;
    }

    public void setValue(@NonNull String value) {
        this.value = value;
    }

    public int getServer() {
        return server;
    }

    public void setServer(int server) {
        this.server = server;
    }
}
