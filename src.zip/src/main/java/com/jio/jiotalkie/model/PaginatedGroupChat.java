package com.jio.jiotalkie.model;

import java.util.List;

public class PaginatedGroupChat {

    private List<JioTalkieChats> chats;
    private boolean isLast;

    public PaginatedGroupChat(List<JioTalkieChats> chats, boolean isLast) {
        this.chats = chats;
        this.isLast = isLast;
    }

    public List<JioTalkieChats> getChats() {
        return chats;
    }

    public boolean isLast() {
        return isLast;
    }
}
