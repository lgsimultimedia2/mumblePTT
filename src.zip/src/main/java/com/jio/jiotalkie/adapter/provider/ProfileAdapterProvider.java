package com.jio.jiotalkie.adapter.provider;

public interface ProfileAdapterProvider {
    public void onItemClick(int id);
}
