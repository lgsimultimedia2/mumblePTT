package com.jio.jiotalkie.adapter.provider;

public interface CalendarUpdateProvider {
    public void update(String update);
}
