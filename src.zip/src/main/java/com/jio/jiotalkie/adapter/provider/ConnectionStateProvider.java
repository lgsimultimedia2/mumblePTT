package com.jio.jiotalkie.adapter.provider;

public interface ConnectionStateProvider {
    public void isConnected(boolean connected);
}
