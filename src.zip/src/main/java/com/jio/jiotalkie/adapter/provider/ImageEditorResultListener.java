package com.jio.jiotalkie.adapter.provider;

import android.net.Uri;

public interface ImageEditorResultListener {
    public void croppedImageUri(Uri uri);
}
