package com.jio.jiotalkie.adapter.provider;

public interface ImageDataProvider {
    void setProfilePic(Object path , boolean isCameraImage);
}
