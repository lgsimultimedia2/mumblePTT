package com.jio.jiotalkie.adapter.provider;

import android.net.Uri;

public interface MediaDataProvider {
    public void getMediaUri(Uri uri);
}
