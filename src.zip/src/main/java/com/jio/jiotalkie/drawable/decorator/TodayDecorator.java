package com.jio.jiotalkie.drawable.decorator;

import android.content.Context;
import android.graphics.Color;
import android.text.style.ForegroundColorSpan;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

import com.jio.jiotalkie.dispatch.R;

public class TodayDecorator implements DayViewDecorator {

    private final CalendarDay today;
    private final Context context;

    public TodayDecorator(Context context, CalendarDay today) {
        this.today = today;
        this.context = context;
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        return today != null && day.equals(today);
    }

    @Override
    public void decorate(DayViewFacade view) {
        // Set the custom background and text color if today is not null
        if (today != null) {
            view.setBackgroundDrawable(context.getDrawable(R.drawable.selected_date_background));
            view.addSpan(new ForegroundColorSpan(Color.WHITE));
        }
    }
}