package com.jio.jiotalkie.drawable.decorator;

import android.content.Context;
import android.graphics.Color;
import android.text.style.ForegroundColorSpan;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

import com.jio.jiotalkie.dispatch.R;

public class SelectedDateDecorator implements DayViewDecorator {
    private final CalendarDay selectedDate;
    private final Context context;

    public SelectedDateDecorator(Context context, CalendarDay selectedDate) {
        this.selectedDate = selectedDate;
        this.context = context;
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        return day.equals(selectedDate);
    }
    @Override
    public void decorate(DayViewFacade view) {
        view.setBackgroundDrawable(context.getDrawable(R.drawable.selected_date_background));
        view.addSpan(new ForegroundColorSpan(Color.WHITE));
    }

}
