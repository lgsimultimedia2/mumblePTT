package com.jio.jiotalkie.drawable.decorator;

import android.graphics.Color;
import android.graphics.Typeface;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

public class CustomDayDecorator implements DayViewDecorator {

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        // This will return true for all days, meaning all days will be decorated
        return true;
    }

    @Override
    public void decorate(DayViewFacade view) {
        // Apply a span to change the text color (e.g., blue)
        view.addSpan(new ForegroundColorSpan(Color.BLUE));

        // Apply a span to make the text bold
        view.addSpan(new StyleSpan(Typeface.BOLD));
    }
}
