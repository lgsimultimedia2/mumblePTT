package com.jio.jiotalkie.drawable.decorator;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.DayViewDecorator;
import com.prolificinteractive.materialcalendarview.DayViewFacade;

public class DisableAfterTodayDecorator implements DayViewDecorator {

    private final CalendarDay today;

    public DisableAfterTodayDecorator() {
        // Get today's date
        today = CalendarDay.today();
    }

    @Override
    public boolean shouldDecorate(CalendarDay day) {
        // Disable dates after today
        return day.isAfter(today);
    }

    @Override
    public void decorate(DayViewFacade view) {
        // Make the day unselectable
        view.setDaysDisabled(true);
    }
}
