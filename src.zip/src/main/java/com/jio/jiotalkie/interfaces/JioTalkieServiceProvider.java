package com.jio.jiotalkie.interfaces;

public interface JioTalkieServiceProvider {

    JioTalkieServiceInterface getService();
}
